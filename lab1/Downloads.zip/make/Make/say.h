void sayHello();
int say(char* word);
