#include "say.h"

int main() {
  sayHello();
  int res = say("world");
  return res;
}
